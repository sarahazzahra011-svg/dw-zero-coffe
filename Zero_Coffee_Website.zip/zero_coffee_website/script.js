const WHATSAPP_NUMBER = "628220386689";
const products = [
 {id:"matcha",name:"Matcha Latte",desc:"Matcha lembut dengan susu creamy yang menyegarkan.",price:25000,img:"https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&w=800&q=80"},
 {id:"americano",name:"Iced Americano",desc:"Espresso dengan es, ringan dan menyegarkan.",price:20000,img:"https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=800&q=80"},
 {id:"cappuccino",name:"Cappuccino",desc:"Perpaduan espresso, susu, dan foam yang lembut.",price:25000,img:"https://images.unsplash.com/photo-1534778101976-62816ab5fdd3?auto=format&fit=crop&w=800&q=80"},
 {id:"caramel",name:"Caramel Latte",desc:"Kopi susu dengan sentuhan manis karamel.",price:27000,img:"https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=800&q=80"},
 {id:"cake",name:"Chocolate Cake",desc:"Kue cokelat lembut untuk teman minum kopi.",price:22000,img:"https://images.unsplash.com/photo-1578985529862-699e9c9b6fc9?auto=format&fit=crop&w=800&q=80"},
 {id:"croissant",name:"Croissant",desc:"Pastry renyah dengan tekstur lembut di dalam.",price:18000,img:"https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=800&q=80"}
];
const cart = {};
const rupiah = n => "Rp " + n.toLocaleString("id-ID");
function renderProducts(filter=""){
 const grid=document.getElementById("productGrid");
 const shown=products.filter(p=>p.name.toLowerCase().includes(filter.toLowerCase()));
 grid.innerHTML=shown.map(p=>`<article class="product-card"><img src="${p.img}" alt="${p.name}" loading="lazy"><div class="product-info"><h3>${p.name}</h3><p>${p.desc}</p><div class="product-bottom"><span class="price">${rupiah(p.price)}</span><button class="add-btn" data-add="${p.id}">+ Tambah</button></div></div></article>`).join("") || '<p>Menu tidak ditemukan.</p>';
}
function renderCart(){
 const entries=Object.entries(cart).filter(([,qty])=>qty>0);
 const container=document.getElementById("cartItems");
 container.innerHTML=entries.length?entries.map(([id,qty])=>{const p=products.find(x=>x.id===id);return `<div class="cart-row"><span>${p.name}<br><small>${rupiah(p.price)}</small></span><div class="qty"><button data-change="${id}" data-delta="-1" aria-label="Kurangi">−</button><span>${qty}</span><button data-change="${id}" data-delta="1" aria-label="Tambah">+</button></div><strong>${rupiah(p.price*qty)}</strong></div>`}).join(""):'<p class="empty-cart">Keranjang kamu masih kosong.</p>';
 const total=entries.reduce((sum,[id,qty])=>sum+products.find(p=>p.id===id).price*qty,0);
 document.getElementById("totalPrice").textContent=rupiah(total);
 document.getElementById("cartCount").textContent=entries.reduce((s,[,q])=>s+q,0);
}
document.addEventListener("click",e=>{
 const add=e.target.closest("[data-add]");
 if(add){cart[add.dataset.add]=(cart[add.dataset.add]||0)+1;renderCart();}
 const change=e.target.closest("[data-change]");
 if(change){const id=change.dataset.change;cart[id]=Math.max(0,(cart[id]||0)+Number(change.dataset.delta));renderCart();}
});
document.getElementById("menuSearch").addEventListener("input",e=>renderProducts(e.target.value));
document.getElementById("searchBtn").addEventListener("click",()=>{document.getElementById("menuSearch").focus();document.getElementById("menu").scrollIntoView({behavior:"smooth"});});
document.getElementById("menuToggle").addEventListener("click",()=>document.getElementById("navLinks").classList.toggle("open"));
document.querySelectorAll("#navLinks a").forEach(a=>a.addEventListener("click",()=>document.getElementById("navLinks").classList.remove("open")));
document.getElementById("orderForm").addEventListener("submit",e=>{
 e.preventDefault();
 const entries=Object.entries(cart).filter(([,q])=>q>0);
 if(!entries.length){alert("Keranjang masih kosong. Silakan pilih menu terlebih dahulu.");return;}
 const name=document.getElementById("customerName").value.trim();
 const phone=document.getElementById("customerPhone").value.trim();
 const note=document.getElementById("customerNote").value.trim();
 const lines=entries.map(([id,q])=>{const p=products.find(x=>x.id===id);return `- ${p.name} x${q} = ${rupiah(p.price*q)}`});
 const total=entries.reduce((s,[id,q])=>s+products.find(p=>p.id===id).price*q,0);
 const message=`Halo Zero Coffee! Saya ingin memesan:%0A%0A${encodeURIComponent(lines.join("\n"))}%0A%0ATotal: ${encodeURIComponent(rupiah(total))}%0A%0ANama: ${encodeURIComponent(name)}%0ANomor WhatsApp: ${encodeURIComponent(phone)}%0ACatatan: ${encodeURIComponent(note||"-")}`;
 window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`,"_blank","noopener");
});
renderProducts();renderCart();

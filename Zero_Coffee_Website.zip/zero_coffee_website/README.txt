ZERO COFFEE WEBSITE

Cara menjalankan:
1. Ekstrak file ZIP.
2. Buka folder zero_coffee_website.
3. Klik dua kali index.html untuk melihat website di browser.

Untuk mendapatkan link publik:
1. Buka https://app.netlify.com/drop
2. Login atau daftar akun Netlify.
3. Seret folder zero_coffee_website (bukan file ZIP) ke area upload.
4. Tunggu proses selesai. Netlify akan memberikan link website publik.

Catatan:
- Nomor WhatsApp tujuan pesanan diatur di script.js: 628220386689.
- Lokasi yang ditampilkan: Sumbersari, Kota Malang, Jawa Timur.
- Jam operasional contoh: 08.00–22.00 WIB, silakan sesuaikan.
- Foto dan Google Fonts membutuhkan koneksi internet.
